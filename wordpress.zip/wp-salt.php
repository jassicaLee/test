<?php
define('AUTH_KEY',         '1?=R`12I.B[FuX+3ESvKskt>es)8:RD8!r V16Z5:|+m+8OF}J:opt*@9p(!+L05');
define('SECURE_AUTH_KEY',  ';r@oKC{Q5tyX5g~Dx${Mm`qvd1_G:?(&>)FM#G4VX5R#%88w[wto%3< .C>Y:*:k');
define('LOGGED_IN_KEY',    'kd+ux/!Z~,:>!K7r}hks;]# Ld{~j|@UVnk~im(+e2>.[N+>&<-Ov9ruu,M]yPi2');
define('NONCE_KEY',        'YmmQn`r7t2@BEOy+4RJ7OGO_J&!D0oHxI%GuY?)lQb$: `c2r<47zfA4*S~[7XJF');
define('AUTH_SALT',        'KB#SyqEsB9}*MM|i/-.G+PR*V-@UBXsBFV4c~!Ag`+QM0HRxltD^),N!Kq!|6.A+');
define('SECURE_AUTH_SALT', '3~OksgDM~-V@K|9jghw&,N*4inN_&)|D|!f-dY.|T{y9$<C94%6-PS?+;Y$=Rk+{');
define('LOGGED_IN_SALT',   '-W(>Bc5s]+q]5:EW4!u.9d^AW1DEjxTB:~}n,dh[Zg^kU2A-(-Kj5A$Y=0563_l{');
define('NONCE_SALT',       '2Yg+;y=0*_{_l4hY[:i#K_JUtB#U#{t<3zq&~Ga3g3H#~QK**|2FH|bkKv*?} TV');
